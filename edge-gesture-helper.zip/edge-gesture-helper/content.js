let enabled = true
let lastClick = { time: 0, x: 0, y: 0 }
const DOUBLE_CLICK_THRESHOLD = 400
const DISTANCE_THRESHOLD = 10

function handleContextMenu(e) {
  if (!enabled || !e.isTrusted) return

  const now = Date.now()
  const dt = now - lastClick.time
  const dx = e.clientX - lastClick.x
  const dy = e.clientY - lastClick.y

  if (dt < DOUBLE_CLICK_THRESHOLD && Math.abs(dx) < DISTANCE_THRESHOLD && Math.abs(dy) < DISTANCE_THRESHOLD) {
    lastClick = { time: 0, x: 0, y: 0 }
    return
  }

  lastClick = { time: now, x: e.clientX, y: e.clientY }
  e.preventDefault()
  e.stopPropagation()
}

window.addEventListener('contextmenu', handleContextMenu, true)

chrome.storage.local.get({ enabled: true }, (result) => {
  enabled = result.enabled
})

chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled) {
    enabled = changes.enabled.newValue
  }
})
